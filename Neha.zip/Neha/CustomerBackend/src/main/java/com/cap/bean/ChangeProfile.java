package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ChangeProfile {

	@Id
	@Column(name="name")
	private String name;
	
	@Column(name="email")
	private String email;
	
	@Column(name="Birth_Month")
	private String birthmonth;
	
	@Column(name="Birth_Day")
	private String birthday;
	
	@Column(name="Birth_Year")
	private String birthyear;
	
	@Column(name="Gender")
	private String gender;
	
	@Column(name="phone")
	private String phone;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBirthmonth() {
		return birthmonth;
	}

	public void setBirthmonth(String birthmonth) {
		this.birthmonth = birthmonth;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getBirthyear() {
		return birthyear;
	}

	public void setBirthyear(String birthyear) {
		this.birthyear = birthyear;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	public ChangeProfile(String name, String email, String birthmonth, String birthday, String birthyear,
			String gender, String phone) {
		super();
		this.name = name;
		this.email = email;
		this.birthmonth = birthmonth;
		this.birthday = birthday;
		this.birthyear = birthyear;
		this.gender = gender;
		this.phone = phone;
	}

	public ChangeProfile() {
		
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", birthmonth=" + birthmonth
				+ ", birthday=" + birthday + ", birthyear=" + birthyear + ", gender=" + gender + ", phone=" + phone
				+ "]";
	}
	
}