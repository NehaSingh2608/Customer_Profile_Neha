package com.cg.capstore.CustomerFrontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cap.capstore")
public class CustomerFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerFrontendApplication.class, args);
	}

}
